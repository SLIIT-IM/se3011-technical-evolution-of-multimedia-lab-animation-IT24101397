
String state = "START"; 
int score = 0;
float timer = 30.0;
int catches = 0;

// Entities
float px, py;           
float hx, hy;           
float ox, oy, ovx, ovy; 
float gx, gy, gvx, gvy; 
boolean goldActive = false;

// Obstacle Box
float obsX = 225, obsY = 160, obsW = 150, obsH = 100;

// 2. SETUP (Runs once)
void setup() {
  size(600, 480);
  resetGame();
}

// 3. MAIN DRAW LOOP (The Brain)
void draw() {
  background(10); 

  if (state.equals("START")) {
    drawScreen("ORB CATCHER", "Press ENTER to Start");
  } 
  else if (state.equals("PLAY")) {
    updateGame();
  } 
  else if (state.equals("END")) {
    drawScreen("GAME OVER", "Final Score: " + score + "\nPress R to Restart");
  }
}

// 4. GAME LOGIC
void updateGame() {
  // Timer Logic
  timer -= 1.0/60.0;
  if (timer <= 0) state = "END";

  // Draw Obstacle
  fill(60);
  rect(obsX, obsY, obsW, obsH);
  fill(255, 100, 0);
  textSize(12);
  text("OBSTACLE", obsX + obsW/2, obsY + obsH/2);

  // Player Movement & Collision
  movePlayer();
  fill(0, 200, 255);
  ellipse(px, py, 30, 30);

  // Helper (Easing logic)
  hx += (px - hx) * 0.1;
  hy += (py - hy) * 0.1;
  fill(0, 200, 255, 100);
  ellipse(hx, hy, 15, 15);

  // Main Orb Logic
  handleOrb();

  // Gold Orb Logic (Appears every 5 catches)
  if (goldActive) {
    handleGoldOrb();
  }

  // UI Display
  fill(255);
  textSize(20);
  textAlign(LEFT);
  text("Score: " + score, 20, 30);
  textAlign(RIGHT);
  text("Time: " + ceil(timer), width - 20, 30);
}

// 5. MOVEMENT & COLLISION
void movePlayer() {
  float nextX = px;
  float nextY = py;

  if (keyPressed) {
    if (keyCode == UP)    nextY -= 5;
    if (keyCode == DOWN)  nextY += 5;
    if (keyCode == LEFT)  nextX -= 5;
    if (keyCode == RIGHT) nextX += 5;
  }

  // Obstacle Collision: Check if next position is inside the box
  if (!(nextX > obsX && nextX < obsX + obsW && nextY > obsY && nextY < obsY + obsH)) {
    px = constrain(nextX, 15, width-15);
    py = constrain(nextY, 15, height-15);
  }
}

void handleOrb() {
  ox += ovx;
  oy += ovy;

  // Bounce off walls
  if (ox < 10 || ox > width-10) ovx *= -1;
  if (oy < 10 || oy > height-10) ovy *= -1;

  fill(255, 200, 0);
  ellipse(ox, oy, 20, 20);

  // Catch detection
  if (dist(px, py, ox, oy) < 25) {
    score++;
    catches++;
    if (catches % 5 == 0) spawnGold();
    resetOrb();
    ovx *= 1.1; // Speed increase
    ovy *= 1.1;
  }
}

void handleGoldOrb() {
  gx += gvx;
  gy += gvy;
  if (gx < 10 || gx > width-10) gvx *= -1;
  if (gy < 10 || gy > height-10) gvy *= -1;

  fill(255, 255, 0);
  ellipse(gx, gy, 25, 25);

  if (dist(px, py, gx, gy) < 25) {
    score += 3;
    goldActive = false;
  }
}

// 6. HELPER FUNCTIONS
void resetOrb() {
  ox = random(width);
  oy = random(height);
  ovx = random(-3, 3);
  ovy = random(-3, 3);
}

void spawnGold() {
  gx = random(width);
  gy = random(height);
  gvx = 5;
  gvy = 5;
  goldActive = true;
}

void resetGame() {
  px = width/2;
  py = height-50;
  hx = px;
  hy = py;
  score = 0;
  timer = 30;
  catches = 0;
  goldActive = false;
  resetOrb();
}

void drawScreen(String title, String sub) {
  textAlign(CENTER, CENTER);
  fill(0, 255, 150);
  textSize(40);
  text(title, width/2, height/2 - 20);
  fill(255);
  textSize(20);
  text(sub, width/2, height/2 + 40);
}

void keyPressed() {
  if (state.equals("START") && keyCode == ENTER) state = "PLAY";
  if (state.equals("END") && (key == 'r' || key == 'R')) {
    resetGame();
    state = "PLAY";
  }
}
